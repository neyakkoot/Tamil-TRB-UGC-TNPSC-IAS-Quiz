document.addEventListener('DOMContentLoaded', async () => {
  const select = document.getElementById('quizSelect');
  const qWrap = document.getElementById('tv-quiz-wrap');
  const qEl = document.getElementById('tv-question');
  const optsEl = document.getElementById('tv-options');
  const feedbackEl = document.getElementById('tv-feedback');
  const progressEl = document.getElementById('tv-progress');
  const nextBtn = document.getElementById('tv-next');
  const resultsEl = document.getElementById('tv-results');

  let quizData = [];
  let idx = 0, score = 0;

  // Load quiz list
  const quizList = await fetch('quiz-list.json').then(r => r.json());
  quizList.forEach(q => {
    const opt = document.createElement('option');
    opt.value = q.file;
    opt.textContent = q.title;
    select.appendChild(opt);
  });

  select.addEventListener('change', () => loadQuiz(select.value));

  async function loadQuiz(file) {
    const res = await fetch(file);
    if (!res.ok) {
      qEl.textContent = '⚠️ வினாடி–வினா கோப்பை ஏற்ற முடியவில்லை!';
      return;
    }
    const data = await res.json();
    quizData = data.questions || data;
    idx = 0; score = 0;
    renderQuestion();
  }

  function renderQuestion() {
    const q = quizData[idx];
    qEl.textContent = q.question || q.questionText;
    optsEl.innerHTML = '';
    feedbackEl.innerHTML = '';
    progressEl.textContent = `வினா ${idx + 1} / ${quizData.length}`;

    const opts = q.options || q.answerOptions.map(a => a.text);
    opts.forEach((opt, i) => {
      const btn = document.createElement('button');
      btn.textContent = opt;
      btn.onclick = () => selectAnswer(i, q.answer ?? q.answerOptions.findIndex(a => a.isCorrect));
      optsEl.appendChild(btn);
    });
  }

  function selectAnswer(i, correct) {
    const buttons = optsEl.querySelectorAll('button');
    buttons.forEach(b => b.disabled = true);
    if (i === correct) {
      score++;
      feedbackEl.innerHTML = '<span style="color:green;">✅ சரியான விடை!</span>';
    } else {
      feedbackEl.innerHTML = '<span style="color:red;">❌ தவறான விடை.</span>';
    }
    nextBtn.style.display = 'block';
  }

  nextBtn.addEventListener('click', () => {
    idx++;
    if (idx < quizData.length) renderQuestion();
    else showResults();
  });

  function showResults() {
    qEl.textContent = '';
    optsEl.innerHTML = '';
    feedbackEl.innerHTML = '';
    progressEl.textContent = '';
    nextBtn.style.display = 'none';
    resultsEl.innerHTML = `<h3>மதிப்பெண்: ${score} / ${quizData.length}</h3><p>சதவீதம்: ${(score / quizData.length * 100).toFixed(1)}%</p>`;
    resultsEl.style.display = 'block';
  }
});